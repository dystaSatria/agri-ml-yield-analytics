import numpy as np
import pandas as pd
import pytest

from src.features import FEATURES, build_yield_dataset, seasonal_weather_features
from src.models import evaluate_models, regression_metrics


def _toy_weather():
    dates = pd.date_range("2020-01-01", "2020-12-31", freq="D")
    return pd.DataFrame({
        "date": dates, "region": "r1",
        "temp_c": 28.0, "rain_mm": np.where(dates.dayofyear % 2 == 0, 0.0, 5.0),
    })


def test_seasonal_features_counts_dry_days():
    feats = seasonal_weather_features(_toy_weather())
    assert feats.loc[0, "dry_days"] + feats.loc[0, "rain_days"] == 366
    assert feats.loc[0, "hot_days"] == 0


def test_build_yield_dataset_has_all_features():
    yields = pd.DataFrame({"region": ["r1"], "year": [2020], "yield_t_ha": [5.0],
                           "rain_total_mm": [900.0], "temp_mean_c": [27.0]})
    df = build_yield_dataset(yields, _toy_weather())
    assert set(FEATURES).issubset(df.columns)


def test_regression_metrics_perfect():
    m = regression_metrics([1.0, 2.0, 3.0], [1.0, 2.0, 3.0])
    assert m["r2"] == pytest.approx(1.0) and m["mae"] == pytest.approx(0.0)


def test_evaluate_models_runs_on_small_data():
    rng = np.random.default_rng(0)
    X = rng.normal(size=(20, len(FEATURES)))
    y = X[:, 0] * 2 + rng.normal(scale=0.1, size=20) + 5
    groups = np.array(["a"] * 10 + ["b"] * 10)
    rows = evaluate_models(X, y, groups)
    assert len(rows) == 4
    assert all("loro_mae" in r for r in rows)
