"""Week 3: execute the analysis, compare models, and simulate scenarios.

Run with:  python -m src.train_yield_model
"""
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.base import clone
from sklearn.inspection import permutation_importance

from src.config import PROCESSED_DIR, REPORTS_DIR, SAMPLE_DIR, RANDOM_SEED
from src.data_pipeline import load_csv
from src.features import FEATURES, build_yield_dataset
from src.models import candidate_models, evaluate_models
from src.eda import to_md_table


def main(data_dir=SAMPLE_DIR, out_dir=REPORTS_DIR) -> str:
    fig_dir = out_dir / "figures"
    fig_dir.mkdir(parents=True, exist_ok=True)
    PROCESSED_DIR.mkdir(parents=True, exist_ok=True)

    weather = load_csv(data_dir / "weather_daily.csv", date_col="date")
    yields = pd.read_csv(data_dir / "yield_seasonal.csv")
    df = build_yield_dataset(yields, weather)
    df.to_csv(PROCESSED_DIR / "yield_model_dataset.csv", index=False)

    X = df[FEATURES].to_numpy(dtype=float)
    y = df["yield_t_ha"].to_numpy(dtype=float)
    groups = df["region"].to_numpy()

    # 1. Model comparison
    results = evaluate_models(X, y, groups)
    summary = pd.DataFrame([{k: v for k, v in r.items() if k != "loro_predictions"} for r in results])
    summary = summary.sort_values("loro_mae").reset_index(drop=True)
    best_name = summary.iloc[0]["model"]
    best_idx = [r["model"] for r in results].index(best_name)
    loro_pred = results[best_idx]["loro_predictions"]

    fig, ax = plt.subplots(figsize=(8, 4))
    x_pos = np.arange(len(summary))
    ax.bar(x_pos - 0.2, summary["cv5_mae"], width=0.4, label="5-fold random CV")
    ax.bar(x_pos + 0.2, summary["loro_mae"], width=0.4, label="Leave-one-region-out")
    ax.set_xticks(x_pos); ax.set_xticklabels(summary["model"], rotation=15)
    ax.set_ylabel("MAE (t/ha)"); ax.set_title("Model comparison (lower is better)"); ax.legend()
    fig.tight_layout(); fig.savefig(fig_dir / "week3_model_comparison.png", dpi=120); plt.close(fig)

    # 2. Predicted vs actual (generalisation to unseen region)
    fig, ax = plt.subplots(figsize=(5.5, 5))
    for region in np.unique(groups):
        m = groups == region
        ax.scatter(y[m], loro_pred[m], label=region)
    lims = [min(y.min(), loro_pred.min()) - 0.2, max(y.max(), loro_pred.max()) + 0.2]
    ax.plot(lims, lims, "k--", lw=1)
    ax.set_xlabel("Actual yield (t/ha)"); ax.set_ylabel("Predicted yield (t/ha)")
    ax.set_title(f"{best_name}: leave-one-region-out"); ax.legend(); ax.grid(alpha=0.3)
    fig.tight_layout(); fig.savefig(fig_dir / "week3_pred_vs_actual.png", dpi=120); plt.close(fig)

    # 3. Final model on all data, feature importance
    final = clone(candidate_models()[best_name]).fit(X, y)
    perm = permutation_importance(final, X, y, n_repeats=30, random_state=RANDOM_SEED)
    imp = pd.DataFrame({"feature": FEATURES, "importance": perm.importances_mean,
                        "std": perm.importances_std}).sort_values("importance", ascending=False)
    fig, ax = plt.subplots(figsize=(7, 4))
    ax.barh(imp["feature"][::-1], imp["importance"][::-1], xerr=imp["std"][::-1])
    ax.set_xlabel("Drop in R² when feature is shuffled"); ax.set_title(f"Permutation importance ({best_name})")
    fig.tight_layout(); fig.savefig(fig_dir / "week3_feature_importance.png", dpi=120); plt.close(fig)

    # 4. Scenario simulation: what if the season is drier or hotter?
    base = df[df["region"] == "region_A"][FEATURES].mean()
    def modify(**changes):
        """Return a copy of the baseline season with some features changed.
        Each value is either a number (set) or a function of the baseline value."""
        row = base.copy()
        for key, rule in changes.items():
            row[key] = rule(base[key]) if callable(rule) else rule
        return row

    scenarios = {
        "Baseline (average region_A season)": base,
        "Drought: rainfall -20%, 15 more dry days": modify(
            rain_total_mm=lambda v: v * 0.8,
            dry_days=lambda v: v + 15,
            rain_days=lambda v: v - 15),
        "Heat: +1.5 C mean temperature": modify(temp_mean_c=lambda v: v + 1.5),
        "Wet season: rainfall +15%": modify(rain_total_mm=lambda v: v * 1.15),
    }
    scen_rows = []
    b_pred = final.predict(base.to_numpy(dtype=float).reshape(1, -1))[0]
    lo, hi = df[FEATURES].min(), df[FEATURES].max()
    for name, row in scenarios.items():
        p = final.predict(row.to_numpy(dtype=float).reshape(1, -1))[0]
        # A scenario is only trustworthy if every input lies within the observed training range.
        inside = bool(((row[FEATURES] >= lo) & (row[FEATURES] <= hi)).all())
        scen_rows.append({"scenario": name, "predicted_yield_t_ha": round(p, 2),
                          "change_vs_baseline_pct": round((p - b_pred) / b_pred * 100, 1),
                          "within_training_range": "yes" if inside else "NO (extrapolation)"})
    scen = pd.DataFrame(scen_rows)

    # 5. Write report section
    lines = ["# Week 3 Model Results", "",
             "Data: synthetic sample (`data/sample/`). Results demonstrate the workflow; they are not agronomic findings.", "",
             "## 1. Model comparison", "",
             to_md_table(summary.round(3)), "",
             f"Selected model (lowest leave-one-region-out MAE): **{best_name}**.", "",
             "## 2. Feature importance", "", to_md_table(imp.round(4)), "",
             "## 3. Scenario simulation", "", to_md_table(scen), "",
             "Figures: `figures/week3_model_comparison.png`, `figures/week3_pred_vs_actual.png`, "
             "`figures/week3_feature_importance.png`.", ""]
    report = "\n".join(lines)
    (out_dir / "week3_model_results.md").write_text(report, encoding="utf-8")
    summary.drop(columns=[]).to_csv(out_dir / "week3_model_comparison.csv", index=False)
    print(report)
    return report


if __name__ == "__main__":
    main()
