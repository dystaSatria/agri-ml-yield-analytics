"""Candidate regression models and evaluation protocols (Week 3)."""
import numpy as np
from sklearn.base import clone
from sklearn.dummy import DummyRegressor
from sklearn.ensemble import GradientBoostingRegressor, RandomForestRegressor
from sklearn.linear_model import Ridge
from sklearn.metrics import mean_absolute_error, r2_score
from sklearn.model_selection import KFold, LeaveOneGroupOut, cross_val_predict
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

from src.config import RANDOM_SEED
from src.kpi import mape


def candidate_models() -> dict:
    """Models compared in Week 3, from the simplest baseline to ensemble methods."""
    return {
        "baseline_mean": DummyRegressor(strategy="mean"),
        "ridge_regression": make_pipeline(StandardScaler(), Ridge(alpha=1.0)),
        "random_forest": RandomForestRegressor(n_estimators=300, min_samples_leaf=2,
                                               random_state=RANDOM_SEED),
        "gradient_boosting": GradientBoostingRegressor(n_estimators=200, learning_rate=0.05,
                                                       max_depth=2, random_state=RANDOM_SEED),
    }


def regression_metrics(y_true, y_pred) -> dict:
    return {
        "r2": float(r2_score(y_true, y_pred)),
        "mae": float(mean_absolute_error(y_true, y_pred)),
        "mape": mape(y_true, y_pred),
    }


def evaluate_models(X: np.ndarray, y: np.ndarray, groups: np.ndarray) -> list[dict]:
    """Two protocols per model:
    - 5-fold random CV: measures fit on seen conditions (optimistic)
    - leave-one-region-out: measures generalisation to a region never seen in training
    """
    rows = []
    kf = KFold(n_splits=5, shuffle=True, random_state=RANDOM_SEED)
    logo = LeaveOneGroupOut()
    for name, model in candidate_models().items():
        pred_kf = cross_val_predict(clone(model), X, y, cv=kf)
        pred_logo = np.empty_like(y, dtype=float)
        for train_idx, test_idx in logo.split(X, y, groups):
            fitted = clone(model).fit(X[train_idx], y[train_idx])
            pred_logo[test_idx] = fitted.predict(X[test_idx])
        m_kf = regression_metrics(y, pred_kf)
        m_logo = regression_metrics(y, pred_logo)
        rows.append({
            "model": name,
            "cv5_r2": m_kf["r2"], "cv5_mae": m_kf["mae"], "cv5_mape": m_kf["mape"],
            "loro_r2": m_logo["r2"], "loro_mae": m_logo["mae"], "loro_mape": m_logo["mape"],
            "loro_predictions": pred_logo,
        })
    return rows
