"""Feature engineering for the yield model (Week 3).

Builds season-level features from daily weather: rainfall total, mean temperature,
and counts of dry and hot days, which capture drought and heat stress.
"""
import pandas as pd

# hot_days is computed but excluded from model inputs: with the sample data the mean
# seasonal temperature never exceeds 30 C, so the column is constant (zero variance).
# See docs/Week3_Execution_and_Modeling.md, section 5.
FEATURES = ["rain_total_mm", "temp_mean_c", "rain_days", "dry_days"]


def seasonal_weather_features(weather: pd.DataFrame, dry_mm: float = 1.0, hot_c: float = 30.0) -> pd.DataFrame:
    """Aggregate daily weather to region-year features.

    dry_days: days with rainfall below dry_mm. hot_days: days with mean temperature above hot_c.
    Missing temperatures are ignored in the counts.
    """
    w = weather.copy()
    w["date"] = pd.to_datetime(w["date"])
    w["year"] = w["date"].dt.year
    out = w.groupby(["region", "year"]).agg(
        rain_days=("rain_mm", lambda s: int((s >= dry_mm).sum())),
        dry_days=("rain_mm", lambda s: int((s < dry_mm).sum())),
        hot_days=("temp_c", lambda s: int((s > hot_c).sum())),
    ).reset_index()
    return out


def build_yield_dataset(yields: pd.DataFrame, weather: pd.DataFrame) -> pd.DataFrame:
    """Join seasonal yield records with weather-derived stress features.

    Region is deliberately NOT a feature, so the model must learn from weather
    rather than from a region identifier. This matters for leave-one-region-out evaluation.
    """
    extra = seasonal_weather_features(weather)
    df = yields.merge(extra, on=["region", "year"], how="left")
    if df[FEATURES].isna().any().any():
        raise ValueError("Missing feature values after join; check region and year coverage.")
    return df
