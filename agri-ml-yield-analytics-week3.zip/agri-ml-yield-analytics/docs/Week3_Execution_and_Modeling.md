---
title: "Week 3 – Execution of Data Analysis and Modeling"
subtitle: "Simulated Analysis and Basic Yield Model for Agriculture and Agribusiness"
---

**Intern:** ____________________ **Programme:** Junior Machine Learning Data Analyst – Agriculture & Agribusiness
**Week:** 3 of 4 **Repository:** https://github.com/<your-username>/agri-ml-yield-analytics

# 1. Introduction and Objectives

Week 1 defined the problem and the plan. Week 2 inventoried the data sources and checked their quality. Week 3 is the execution phase: explore the data, select suitable algorithms, build a basic machine learning model, and turn its outputs into statements that could guide decisions in agricultural practice.

The objectives for this week were to:

1. Explore the prepared data and identify patterns that matter for crop yield.
2. Select and justify machine learning algorithms suited to agricultural data.
3. Build and evaluate models with a protocol that tests generalisation, not only fit.
4. Simulate decision scenarios and connect model outputs to practical actions.
5. Document assumptions, challenges, and recommendations.

**Important note on data.** This week uses the synthetic sample dataset (`data/sample/`), because the real datasets are still being accessed (see Week 2). The synthetic data was generated with known relationships between weather and yield, plus random noise. The analysis therefore demonstrates a correct workflow and reveals how models behave, but its numerical results are **not agronomic findings**. Section 9 explains what must change when real data is used.

# 2. Preliminary Data Exploration Plan

The plan builds on the Week 2 data quality assessment and is executed in the following order:

| Step | Question | Method | Output |
|------|----------|--------|--------|
| E1 | Is the data complete, consistent, and plausible? | Profiling and range checks (Week 2 code) | Clean input confirmed |
| E2 | How does yield vary across regions and years? | Summary statistics by region | Baseline yield levels |
| E3 | Which weather variables move with yield? | Correlation and scatter plots | Candidate features |
| E4 | Are features redundant or constant? | Variance and correlation between features | Feature shortlist |
| E5 | Does the relationship depend on region? | Region-stratified comparison | Need for region-aware evaluation |
| E6 | Do the results hold for unseen regions? | Leave-one-region-out validation | Generalisation estimate |

The exploration deliberately starts with simple relationships before any model is fitted, so that model results can be checked against an understanding of the data rather than accepted as output.

# 3. Data Preparation for Modelling

The seasonal yield table (20 records: 2 regions × 10 years) was joined with weather-derived features computed from 7,306 daily observations (`src/features.py`):

- **rain_total_mm:** total seasonal rainfall.
- **temp_mean_c:** mean seasonal temperature.
- **rain_days:** number of days with rainfall of at least 1 mm.
- **dry_days:** number of days with rainfall below 1 mm, a proxy for drought stress.
- **hot_days:** number of days with mean temperature above 30 °C, a proxy for heat stress. It is computed but **excluded** from model inputs (see Section 5).

Region was **not** used as a feature. Including a region identifier would let the model memorise regional levels, which would hide whether weather actually explains yield. This choice is tested directly in the evaluation.

# 4. Exploration Findings

## 4.1 Yield and weather by region

| Variable | region_A mean (min–max) | region_B mean (min–max) |
|----------|------------------------|------------------------|
| Yield (t/ha) | 6.12 (5.50–6.58) | 6.68 (6.25–7.19) |
| Annual rainfall (mm) | 873.8 (741.7–995.9) | 871.2 (757.6–1035.1) |
| Mean temperature (°C) | 26.99 (26.84–27.09) | 27.03 (26.97–27.11) |
| Dry days per season | 206.7 (192–218) | 210.4 (193–226) |

**Finding 1: region B is consistently about 0.56 t/ha more productive than region A**, even though rainfall and temperature are nearly identical. The difference is not explained by the weather variables in the dataset.

**Finding 2: rainfall is the dominant weather variable.** The correlation between annual rainfall and yield is 0.29 across all records (Week 2 report). Rainfall varies much more than temperature, which is almost constant in this sample: the standard deviation of mean temperature is only 0.06 °C.

**Finding 3: temperature has almost no variability.** Because temperature barely changes across seasons, any effect estimated from it is weakly identified. This becomes important in the scenario analysis (Section 7).

# 5. Algorithm Selection

## 5.1 Selection criteria

Algorithms were chosen against four criteria drawn from the data characteristics and the decision context:

1. **Small sample size:** only 20 seasonal records are available in the sample, so models must not be over-parameterised.
2. **Interpretability:** agronomists and managers need to understand why a prediction changed.
3. **Non-linearity:** crop response to temperature is known to be non-linear, with yield declining above an optimum temperature.
4. **Operational simplicity:** the model must be retrainable and explainable by a small team.

## 5.2 Candidate algorithms

**(a) Mean baseline.** Predicts the average historical yield for every season. It provides the minimum performance any useful model must beat.

**(b) Ridge regression.** Linear regression with an L2 penalty on coefficients (Hoerl & Kennard, 1970). The penalty shrinks coefficients toward zero, which stabilises estimates when predictors are correlated, as rainfall-based features are. Its coefficients are directly interpretable.

```
Yield = b0 + b1*rain_total + b2*temp_mean + b3*rain_days + b4*dry_days
Loss  = sum((Yield_actual - Yield_pred)^2) + alpha * sum(b_j^2)
```

**(c) Random forest.** An ensemble of decision trees trained on bootstrap samples with random feature subsets, whose predictions are averaged (Breiman, 2001). It captures non-linear effects and interactions without manual specification, and is robust to outliers.

```
for t in 1..300:
    sample training rows with replacement
    grow a regression tree; at each split consider a random subset of features
    choose split that minimises squared error
prediction = average of the 300 tree predictions
```

**(d) Gradient boosting.** Trees are added sequentially, each one fitted to the errors of the current ensemble (Friedman, 2001). Shallow trees (depth 2) are used to limit overfitting, which matters with few samples.

```
F0 = mean(y)
for m in 1..200:
    residual_i = y_i - F(m-1)(x_i)
    fit shallow tree h_m to residuals
    F_m = F(m-1) + learning_rate * h_m
```

## 5.3 Pipeline

```
 Seasonal yields ─┐
                  ├─► Join on region & year ─► Feature matrix ─┬─► Mean baseline
 Daily weather ───┘   (rain, temp, dry/rain days)            ├─► Ridge
   └─► Aggregate per season                                    ├─► Random forest
                                                               └─► Gradient boosting
                                                                       │
                              5-fold CV  +  leave-one-region-out ◄─────┘
                                                                       │
                       Best model ─► permutation importance ─► scenario simulation
```

## 5.4 Rationale and tools

Ridge regression was included because it is the most interpretable option and because a linear model is a defensible first approximation over the observed range. The tree-based models were included because the crop response to temperature is known to be non-linear. Gradient boosting with shallow trees was chosen as the strongest candidate for larger real datasets. Tools: Python, pandas, scikit-learn (Pedregosa et al., 2011), matplotlib. A deep learning model was deliberately **not** used for the yield task: with about 20 records, neural networks would overfit, and the image-based CNN belongs to the disease task in a later week.

# 6. Evaluation Protocol

Two protocols were used, because they answer different questions:

- **5-fold random cross-validation** checks whether the model fits seasons similar to those it has seen. Because seasons from the same region can appear in both training and test folds, this protocol is optimistic.
- **Leave-one-region-out (LORO)** trains on one region and tests on the other. It answers the operational question: *does the model work in a region where it has never been calibrated?* This is the stricter test and the one used for model selection.

Metrics: R², mean absolute error (MAE, in t/ha, easy for agronomists to interpret), and MAPE (for consistency with the KPI targets in Week 1).

# 7. Results

## 7.1 Model comparison

| Model | 5-fold R² | 5-fold MAE | LORO R² | LORO MAE (t/ha) | LORO MAPE |
|-------|-----------|------------|---------|-----------------|-----------|
| Ridge regression | 0.24 | 0.32 | −0.75 | **0.50** | 7.9% |
| Random forest | −0.32 | 0.41 | −1.18 | 0.55 | 8.6% |
| Mean baseline | −0.03 | 0.35 | −1.28 | 0.56 | 8.8% |
| Gradient boosting | −1.15 | 0.51 | −1.42 | 0.58 | 9.0% |

Ridge regression was selected by lowest LORO MAE. Several results need careful interpretation:

- **Ridge is the only model that beats the baseline under both protocols**, but the margin is small (0.50 versus 0.56 t/ha under LORO).
- **All models have negative LORO R².** A negative R² means that predictions for an unseen region are worse, in squared-error terms, than simply predicting that region's own average. The cause is Finding 1: region B's higher yield is not explained by weather, so a model trained on region A systematically underestimates region B. MAE is less affected than R² because it penalises errors linearly.
- **Tree models underperform** on 20 records. Their flexibility allows them to fit noise, which is the expected failure mode for small samples.

## 7.2 Feature importance

Permutation importance measures how much R² drops when one feature is shuffled. Results for the selected ridge model:

| Feature | Importance (drop in R²) | Std |
|---------|--------------------------|-----|
| rain_total_mm | 1.02 | 0.26 |
| temp_mean_c | 0.21 | 0.10 |
| dry_days | 0.19 | 0.13 |
| rain_days | 0.18 | 0.12 |

Total rainfall carries most of the signal. Dry-day and rain-day counts add some information, but they are strongly correlated with total rainfall, so their individual contributions are not separable. Importance values should be read as "what the model relies on", not as causal effects.

## 7.3 Accuracy in practical terms

With LORO MAE of 0.50 t/ha on a mean yield of about 6.4 t/ha, the typical error is roughly 8%. This is close to the 15% MAPE target set in Week 1, but it is achieved on synthetic data and must be re-tested on real regional statistics.

# 8. Scenario Simulation

The selected model, refitted on all data, was used to test four decision scenarios for an average region A season. Every scenario input was checked against the range observed in training.

| Scenario | Predicted yield (t/ha) | Change vs baseline | Within training range? |
|----------|------------------------|--------------------|------------------------|
| Baseline (average season) | 6.32 | – | Yes |
| Drought: rainfall −20%, 15 more dry days | 6.00 | −5.1% | **No** |
| Heat: +1.5 °C mean temperature | 9.64 | +52.4% | **No** |
| Wet season: rainfall +15% | 6.85 | +8.3% | Yes |

**Only the wet-season scenario is a reliable estimate.** The drought and heat scenarios lie outside the range of the training data, so the model is extrapolating. The heat result (+52%) is clearly implausible: a 1.5 °C warming cannot raise yield by half. It arises because temperature varies by only 0.06 °C in the sample, so the model's temperature coefficient is estimated from noise and is then multiplied by an input far outside the data. The drought estimate is directionally sensible, but its magnitude is also unverified.

This is the most important lesson of the week for practical use: **a model that produces a precise-looking number is not automatically a decision tool.** Scenario outputs must be accompanied by a check that the inputs are supported by data.

# 9. Insights

1. **Rainfall is the primary driver of yield in this dataset**, and the model relies on it far more than on any other variable.
2. **Location matters beyond weather.** The 0.56 t/ha gap between regions with identical climate indicates unmeasured factors such as soil quality, variety, irrigation, or management. Without them, the model cannot be transferred to a new region reliably.
3. **Simple models are competitive with complex ones on small data.** Ridge regression outperformed random forest and gradient boosting, so model complexity should be justified by data volume.
4. **Temperature effects cannot be estimated from low-variance data.** Heat-stress conclusions require observations that actually include hot seasons.
5. **Evaluation design changes the conclusion.** Random cross-validation suggests reasonable fit; leave-one-region-out shows that transfer to a new region is much weaker.

# 10. Potential Business Impact

If validated on real data, the approach could support several practical decisions:

- **Harvest and sales planning:** an early yield estimate, updated as the season progresses, helps agribusiness firms plan storage, contracts, and procurement volumes.
- **Input allocation:** rainfall-based yield signals can guide timing of fertiliser and irrigation, especially where rainfall data is available before the critical growth stages.
- **Risk management:** scenario tools can estimate the yield impact of drought or heat, supporting insurance decisions, credit assessment, and contingency planning.
- **Regional prioritisation:** region-level residuals (the gap between predicted and actual yield) identify areas where something other than weather limits production, directing extension programmes or investment.

These impacts depend on predictive accuracy in new regions and seasons. Until validated, outputs should be treated as decision support, to be combined with agronomic judgement.

# 11. Recommendations for Further Steps

1. **Collect real data first.** Replace the synthetic sample with BPS district yields and NASA POWER weather for the pilot regions (Week 2 plan).
2. **Add region-level and soil features** (soil type, irrigation access, variety) to explain the structural yield gap identified in Insight 2.
3. **Extend the time series.** Target at least 10 seasons per district so that temperature and drought effects can be estimated from real variation.
4. **Add satellite vegetation indices (NDVI, EVI)** from Sentinel-2 at key growth stages; these often explain more variation than weather alone.
5. **Use scenario outputs only inside the observed range,** and flag any extrapolation automatically, as implemented in `src/train_yield_model.py`.
6. **Introduce non-linear terms or constrained models for temperature** once data contains enough hot seasons, for example a response curve with an optimum temperature.
7. **Establish a monitoring routine:** retrain each season, track LORO error over time, and compare predictions with harvest outcomes.
8. **Engage agronomists** to review feature effects and scenario plausibility before any results reach farmers or managers.

# 12. Assumptions, Challenges, and Outcomes

## 12.1 Assumptions

- The synthetic data reflects a plausible but simplified weather–yield relationship.
- Seasonal aggregation of daily weather is a reasonable representation of the growing season.
- Regions A and B are representative of the pilot setting (to be verified with real data).
- Yield measured per season is the target variable; harvest timing differences are ignored.

## 12.2 Challenges

- **Very small sample** (20 records) limits what can be learned and makes metrics noisy.
- **Near-constant temperature** prevented estimation of heat effects and produced an unreliable heat scenario.
- **Unobserved regional differences** caused negative LORO R², despite acceptable MAE.
- **Feature redundancy:** rainfall totals and day counts are strongly related, so their importance cannot be separated cleanly.
- **Extrapolation risk** was discovered during scenario testing, not during model fitting, which shows why scenario checks belong in the evaluation pipeline.

## 12.3 Final outcomes

- A reproducible pipeline (`src/features.py`, `src/models.py`, `src/train_yield_model.py`) that compares four models under two validation protocols, computes feature importance, and runs scenarios with range checks.
- A selected baseline model (ridge regression) with LORO MAE of 0.50 t/ha on synthetic data, and a clear understanding of its limits.
- Three figures: model comparison, predicted versus actual under LORO, and feature importance (`reports/figures/`).
- Fifteen passing unit tests in total (7 from Week 1, 4 from Week 2, 4 from Week 3), covering pipeline, metrics, features, and model evaluation.

# 13. Conclusion

Week 3 demonstrated the full execution cycle for a yield model: exploration, algorithm selection with explicit rationale, evaluation under a protocol that tests transfer to new regions, and scenario simulation. The most valuable findings were negative: the model does not transfer well between regions without location-specific information, and scenario outputs can look precise while being unsupported by the data. These are exactly the risks a decision-maker must understand before using a model. The next step is to replace the synthetic data with real regional statistics and test whether these conclusions hold.

# References

Breiman, L. (2001). Random forests. *Machine Learning, 45*(1), 5–32.

Friedman, J. H. (2001). Greedy function approximation: A gradient boosting machine. *The Annals of Statistics, 29*(5), 1189–1232.

Hoerl, A. E., & Kennard, R. W. (1970). Ridge regression: Biased estimation for nonorthogonal problems. *Technometrics, 12*(1), 55–67.

Liakos, K. G., Busato, P., Moshou, D., Pearson, S., & Bochtis, D. (2018). Machine learning in agriculture: A review. *Sensors, 18*(8), 2674.

Chlingaryan, A., Sukkarieh, S., & Whelan, B. (2018). Machine learning approaches for crop yield prediction and nitrogen status estimation in precision agriculture: A review. *Computers and Electronics in Agriculture, 151*, 61–69.

Pedregosa, F., Varoquaux, G., Gramfort, A., et al. (2011). Scikit-learn: Machine learning in Python. *Journal of Machine Learning Research, 12*, 2825–2830.
