# Week 3 Model Results

Data: synthetic sample (`data/sample/`). Results demonstrate the workflow; they are not agronomic findings.

## 1. Model comparison

| model | cv5_r2 | cv5_mae | cv5_mape | loro_r2 | loro_mae | loro_mape |
|---|---|---|---|---|---|---|
| ridge_regression | 0.24 | 0.32 | 5.079 | -0.75 | 0.499 | 7.855 |
| random_forest | -0.323 | 0.41 | 6.476 | -1.183 | 0.549 | 8.636 |
| baseline_mean | -0.025 | 0.347 | 5.459 | -1.284 | 0.561 | 8.832 |
| gradient_boosting | -1.153 | 0.51 | 8.09 | -1.416 | 0.579 | 9.036 |

Selected model (lowest leave-one-region-out MAE): **ridge_regression**.

## 2. Feature importance

| feature | importance | std |
|---|---|---|
| rain_total_mm | 1.0193 | 0.2635 |
| temp_mean_c | 0.2148 | 0.0991 |
| dry_days | 0.1888 | 0.1294 |
| rain_days | 0.1765 | 0.1242 |

## 3. Scenario simulation

| scenario | predicted_yield_t_ha | change_vs_baseline_pct | within_training_range |
|---|---|---|---|
| Baseline (average region_A season) | 6.32 | 0.0 | yes |
| Drought: rainfall -20%, 15 more dry days | 6.0 | -5.1 | NO (extrapolation) |
| Heat: +1.5 C mean temperature | 9.64 | 52.4 | NO (extrapolation) |
| Wet season: rainfall +15% | 6.85 | 8.3 | yes |

Figures: `figures/week3_model_comparison.png`, `figures/week3_pred_vs_actual.png`, `figures/week3_feature_importance.png`.
