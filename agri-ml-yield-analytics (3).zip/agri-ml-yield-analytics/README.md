# Agriculture & Agribusiness Machine Learning Data Analytics

Junior Machine Learning Data Analyst internship project (20 Oct 2026 – 17 Nov 2026).

This repository contains the strategic plan, data pipeline, KPI evaluation utilities, and tests for a machine learning project focused on agriculture and agribusiness. The project covers three analytical goals:

1. **Crop yield prediction** from weather data and satellite-derived vegetation indices.
2. **Early plant disease detection** from leaf images (image classification).
3. **Short-term commodity price forecasting** to support sales planning.

## Status

| Week | Task | Status |
|------|------|--------|
| 1 | Strategic Design and Planning | Completed (see `docs/`) |
| 2 | Data Understanding and Source Inventory | Completed (see `docs/Week2_Data_Understanding.md`) |
| 3 | Execution of Data Analysis and Modeling | Completed (see `docs/Week3_Execution_and_Modeling.md`) |
| 4 | Project Evaluation, Reporting, and Recommendations | Completed (see `docs/Week4_Final_Project_Report.docx`) |

## Repository structure

```
.
├── README.md
├── LICENSE
├── requirements.txt
├── docs/
│   ├── Week1_Strategic_Plan.md      # Strategy document (English)
│   ├── Week1_Strategic_Plan.docx    # Same document in Word format
│   ├── Week2_Data_Understanding.md  # Source inventory, data dictionary, quality, EDA
│   ├── Week2_Data_Understanding.docx
│   ├── Week3_Execution_and_Modeling.md  # Exploration, algorithms, results, scenarios
│   ├── Week3_Execution_and_Modeling.docx
│   ├── Week4_Final_Project_Report.md    # Final report: phases, results, recommendations
│   └── Week4_Final_Project_Report.docx
├── src/
│   ├── config.py                    # Paths, random seed, KPI targets
│   ├── data_pipeline.py             # Loading, cleaning, outlier removal, time split
│   ├── kpi.py                       # MAPE, R², and KPI target checks
│   ├── data_quality.py              # Profiling, coverage, duplicate, and range checks
│   ├── eda.py                       # Week 2 EDA and quality report generator
│   ├── features.py                  # Seasonal weather features and yield dataset
│   ├── models.py                    # Candidate models and LORO / CV evaluation
│   ├── train_yield_model.py         # Week 3 pipeline: comparison, importance, scenarios
│   ├── project_status.py            # Week 4: checks that all deliverables exist
│   └── generate_sample_data.py      # Synthetic data for testing the pipeline
├── tests/
│   ├── test_kpi.py
│   └── test_pipeline.py
├── data/
│   ├── README.md                    # Data sources and licensing notes
│   ├── catalogue.csv                # Dataset catalogue (Week 2)
│   ├── raw/                         # Original data (not versioned)
│   ├── processed/                   # Cleaned data (not versioned)
│   └── sample/                      # Small synthetic dataset (versioned)
├── notebooks/                       # Exploratory analysis (Week 2 onward)
└── reports/                         # Generated figures and results
```

## Getting started

Requirements: Python 3.10 or newer.

```bash
git clone https://github.com/<your-username>/agri-ml-yield-analytics.git
cd agri-ml-yield-analytics
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

Generate the synthetic sample data and run the tests:

```bash
python -m src.generate_sample_data
python -m pytest -q
python -m src.eda                  # writes reports/week2_data_quality.md
python -m src.train_yield_model    # writes reports/week3_model_results.md
python -m src.project_status       # writes reports/project_status.md
```

## KPI targets

| KPI | Target |
|-----|--------|
| Yield model R² | ≥ 0.70 |
| Yield model MAPE | ≤ 15% |
| Disease classifier accuracy | ≥ 90% |
| Disease classifier macro F1 | ≥ 0.85 |
| 4-week price forecast MAPE | ≤ 10% |

The targets are defined in `src/config.py` and the full rationale is in `docs/Week1_Strategic_Plan.md`.

## Data

Real datasets are not committed to this repository. Sources, licences, and access instructions are listed in `data/README.md`. The files in `data/sample/` are synthetic and exist only to test the pipeline.

## Methodology

The project follows the CRISP-DM framework (business understanding, data understanding, data preparation, modelling, evaluation, deployment). Validation uses time-based splits and region-grouped cross-validation to avoid data leakage and to test generalisation to unseen regions.

## License

MIT. See `LICENSE`.
