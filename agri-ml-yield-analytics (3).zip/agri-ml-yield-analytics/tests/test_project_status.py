from src.project_status import DELIVERABLES, check_deliverables


def test_every_deliverable_is_listed():
    status = check_deliverables()
    assert len(status) == len(DELIVERABLES)
    assert set(status.columns) == {"deliverable", "path", "present"}
