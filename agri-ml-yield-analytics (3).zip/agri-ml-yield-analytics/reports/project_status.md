# Project Status

Deliverables present: 7 of 7.

| deliverable | path | present |
|---|---|---|
| Week 1 strategic plan (Word) | docs/Week1_Strategic_Plan.docx | True |
| Week 2 data understanding (Word) | docs/Week2_Data_Understanding.docx | True |
| Week 3 execution and modelling (Word) | docs/Week3_Execution_and_Modeling.docx | True |
| Week 4 final project report (Word) | docs/Week4_Final_Project_Report.docx | True |
| Dataset catalogue | data/catalogue.csv | True |
| Week 2 data quality report | reports/week2_data_quality.md | True |
| Week 3 model results | reports/week3_model_results.md | True |
