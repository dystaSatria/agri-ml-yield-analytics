---
title: "Final Project Report"
subtitle: "Machine Learning Data Analysis for Agriculture and Agribusiness: Planning, Analysis, Findings, and Recommendations"
---

**Intern:** ____________________ **Programme:** Junior Machine Learning Data Analyst – Agriculture & Agribusiness
**Period:** 20 October 2026 – 17 November 2026 **Repository:** https://github.com/<your-username>/agri-ml-yield-analytics

# 1. Introduction

## 1.1 Background

Agriculture must produce more food while coping with climate variability, pest and disease pressure, and volatile markets. Decisions about planting, input use, harvest timing, and sales are often taken with incomplete information. Data-driven methods can narrow that gap, but only if the work is planned, the data is checked, the models are tested honestly, and the results are communicated in terms that decision-makers can act on.

## 1.2 Purpose of this report

This report closes the four-week internship project. It synthesises the work of Weeks 1 to 3, describes the methodology used, reports the analysis and its outcomes, states the findings and limitations, and proposes recommendations and next steps for agribusiness operations.

## 1.3 Scope and an important caveat

The project was designed as a simulated end-to-end analysis. The modelling used a **synthetic sample dataset** generated with known relationships between weather and yield plus random noise, because real regional datasets were still being accessed when the analysis was carried out. The workflow, methods, and evaluation logic are production-relevant. The numerical results are not agronomic facts and must not be used for operational decisions until the pipeline is re-run on real data. Section 8 returns to this point.

## 1.4 Structure

Section 2 summarises each project phase. Section 3 sets out the methodology. Section 4 presents the analysis and results. Section 5 gives the findings. Section 6 evaluates the project against its KPIs. Section 7 formulates recommendations. Section 8 discusses real-world implications and limitations. Section 9 proposes next steps. Section 10 reflects on the learning journey.

# 2. Summary of Project Phases

## 2.1 Phase 1: Strategic planning (Week 1)

Week 1 translated a broad interest in agricultural analytics into a testable plan. The central research question was how machine learning, built on open and historical data, could predict crop yield, detect plant disease early, and forecast commodity prices with enough accuracy to support decisions.

The plan defined five SMART objectives, from integrating data (O1) to delivering a dashboard (O5), with numerical targets: yield model R² of at least 0.70 and MAPE of at most 15%; disease classifier accuracy of at least 90% and macro F1 of at least 0.85; and a four-week price forecast MAPE of at most 10%. Scope was limited to one staple commodity and one or two pilot regions. The methodology followed CRISP-DM. A risk register with ten risks and mitigations was produced, and it identified the two most serious early risks: incomplete yield records and models that do not generalise.

## 2.2 Phase 2: Data acquisition and understanding (Week 2)

Week 2 inventoried six candidate datasets and recorded their provider, licence, coverage, and access status in `data/catalogue.csv`. Satellite imagery (Sentinel-2), daily weather (NASA POWER), district yield statistics (BPS), global yield statistics (FAOSTAT), leaf images (PlantVillage), and commodity prices (source still to be selected) form the candidate evidence base.

The data quality assessment, implemented in `src/data_quality.py` and `src/eda.py`, checked completeness, duplicates, date coverage, and value plausibility. On the sample data the weather table contained 7,306 daily records for two regions over ten years with no duplicates and no date gaps, and 2.09% of temperature readings were missing. The yield table contained 20 region–season records with no missing values. Exploratory analysis showed a clear annual rainfall cycle and a weak positive correlation between annual rainfall and yield (r = 0.29).

## 2.3 Phase 3: Data preparation (Week 2–3)

Preparation consisted of cleaning, joining, and feature construction. Duplicate records were removed by key. Missing temperature values were filled by time-based interpolation. Daily weather was aggregated to region–season features: total rainfall, mean temperature, rain days (≥ 1 mm), and dry days (< 1 mm). A hot-day count (> 30 °C) was computed but excluded because it had zero variance in the sample. Region was deliberately not used as a model input, so that the evaluation could test whether weather alone explains yield.

## 2.4 Phase 4: Analysis and modelling (Week 3)

Week 3 compared four models: a mean baseline, ridge regression, random forest, and gradient boosting. Each was evaluated with two protocols. Five-fold random cross-validation measures fit to familiar conditions and is optimistic. Leave-one-region-out (LORO) trains on one region and tests on another and was used for model selection, because it measures transfer to a location the model has not seen. Ridge regression was selected on LORO mean absolute error. Permutation importance and a set of scenario simulations were then produced, and each scenario was checked against the range of the training data.

# 3. Methodology

## 3.1 Analytical framework

The project followed CRISP-DM (Shearer, 2000): business understanding (Week 1), data understanding (Week 2), data preparation (Weeks 2–3), modelling (Week 3), evaluation (Weeks 3–4), and deployment planning (Week 4). The phases were iterative. In Week 3, for example, the scenario checks led to the removal of a feature and to a change in how scenarios are reported.

## 3.2 Data

| Dataset | Content | Size in sample | Status |
|---------|---------|----------------|--------|
| Daily weather | Temperature, rainfall, two regions | 7,306 rows | Synthetic; real source identified (NASA POWER) |
| Seasonal yield | Yield, rainfall total, mean temperature | 20 rows | Synthetic; real source identified (BPS, FAOSTAT) |
| Satellite imagery | NDVI and vegetation indices | Not yet used | Access pending (Sentinel-2) |
| Leaf images | Disease classes | Not yet used | Public dataset identified (PlantVillage) |
| Commodity prices | Monthly or weekly prices | Not yet used | Source not yet selected |

## 3.3 Models and protocol

The yield model predicted seasonal yield (t/ha) from four features: total rainfall, mean temperature, rain days, and dry days. Four candidate algorithms were compared. Ridge regression is a linear model with an L2 penalty that stabilises coefficients when predictors are correlated. Random forest (Breiman, 2001) averages many decision trees trained on resampled data, and gradient boosting (Friedman, 2001) adds shallow trees sequentially to correct earlier errors. The mean baseline sets the minimum performance any model must exceed.

Metrics were R², mean absolute error (MAE, in t/ha), and MAPE, computed with the same definition used in the Week 1 KPIs.

## 3.4 Reproducibility

All steps are implemented in the repository. Random seeds are fixed in `src/config.py`. Unit tests (15 in total) cover the data pipeline, quality checks, features, metrics, and model evaluation. Generated reports and figures are written to `reports/`, and `src/project_status.py` checks that every deliverable is present.

# 4. Analysis and Results

## 4.1 Exploratory results

Yield differed between regions (region A mean 6.12 t/ha; region B mean 6.68 t/ha) even though their average rainfall (about 873 mm and 871 mm) and temperature (about 27.0 °C) were almost identical. Rainfall explained more of the year-to-year variation than temperature, which barely varied across seasons (standard deviation 0.06 °C).

## 4.2 Model comparison

| Model | 5-fold R² | 5-fold MAE | LORO R² | LORO MAE (t/ha) | LORO MAPE |
|-------|-----------|------------|---------|-----------------|-----------|
| Ridge regression (selected) | 0.24 | 0.32 | −0.75 | **0.50** | 7.9% |
| Random forest | −0.32 | 0.41 | −1.18 | 0.55 | 8.6% |
| Mean baseline | −0.03 | 0.35 | −1.28 | 0.56 | 8.8% |
| Gradient boosting | −1.15 | 0.51 | −1.42 | 0.58 | 9.0% |

Ridge was the only model that beat the mean baseline under both protocols, although the margin was small. The tree-based models overfitted the 20 records.

## 4.3 Feature importance

Shuffling total rainfall reduced R² by about 1.02, far more than any other feature (temperature 0.21, dry days 0.19, rain days 0.18). Dry-day and rain-day counts are strongly related to total rainfall, so their individual contributions cannot be separated reliably.

## 4.4 Scenario simulation

| Scenario (average region A season) | Predicted yield | Change | Input within training range? |
|------------------------------------|-----------------|--------|-------------------------------|
| Baseline | 6.32 t/ha | – | Yes |
| Drought: rainfall −20%, 15 more dry days | 6.00 t/ha | −5.1% | No |
| Heat: +1.5 °C mean temperature | 9.64 t/ha | +52.4% | No |
| Wet season: rainfall +15% | 6.85 t/ha | +8.3% | Yes |

Only the wet-season scenario lies within the observed data. The drought and heat results are extrapolations. The heat result is implausible and is interpreted in Section 5.

# 5. Findings

**Finding 1: Rainfall is the main weather driver of yield in the dataset.** Its importance is several times larger than any other feature, and the wet-season scenario gives a plausible response (+8%). This is consistent with the agronomic expectation that water availability limits yield in many staple systems.

**Finding 2: Location explains a large share of yield that weather does not.** Two regions with the same climate differ by 0.56 t/ha. This is why models trained in one region underperform in another (LORO R² below zero). In practice the gap points to soil quality, varieties, irrigation access, or management practices, all of which are missing from the feature set. This is the most important finding for operations: a weather-only model cannot be transferred between sites without location-specific information.

**Finding 3: Simple models are more reliable than complex ones on small samples.** Ridge regression outperformed random forest and gradient boosting, which fitted noise. Model complexity should be justified by data volume, not by default.

**Finding 4: Scenario outputs can look precise and still be wrong.** The heat scenario predicted a 52% increase in yield from a 1.5 °C warming. This arose because the training data contained almost no temperature variation, so the model's temperature effect was estimated from noise and then applied far outside the observed range. The lesson is that a numerical output is not a decision unless its inputs are supported by data. Range checks were added to the pipeline in response.

**Finding 5: The evaluation protocol changes the conclusion.** Random cross-validation suggests a usable model (R² 0.24, MAE 0.32). Region-based validation shows that the same model has a larger error and no predictive skill beyond the average in a new region (R² −0.75). Operational claims must therefore be based on the stricter test.

# 6. Evaluation Against Project KPIs

| KPI (Week 1 target) | Result | Status |
|---------------------|--------|--------|
| Yield model R² ≥ 0.70 | 0.24 (5-fold); −0.75 (LORO) | **Not met** |
| Yield model MAPE ≤ 15% | 7.9% (LORO, synthetic) | Met on synthetic data only |
| Disease classifier accuracy ≥ 90% | Not built in this simulation | Not started |
| Disease classifier macro F1 ≥ 0.85 | Not built in this simulation | Not started |
| Price forecast MAPE ≤ 10% (4 weeks) | Not built in this simulation | Not started |
| Integrated dataset from ≥ 3 sources (O1) | Sources identified and catalogued; real integration pending | Partially met |
| Reproducibility (pipeline reruns identically) | Fixed seeds; tests pass; reports regenerate | Met |
| Documentation of all modules | Docstrings, README, and weekly reports | Met |

The honest assessment is that the project met its process and reproducibility goals and produced a validated workflow, but it did not meet its technical model targets. The R² target was not reached, and two of the three models were not built. The MAPE result is encouraging but is measured on synthetic data, so it is not evidence of field performance. These gaps are stated plainly because a report that hides them would be less useful to a decision-maker.

# 7. Recommendations

The recommendations are ordered by priority and feasibility.

| No | Recommendation | Rationale | Feasibility | Priority |
|----|----------------|-----------|-------------|----------|
| R1 | Re-run the entire pipeline on real BPS yield and NASA POWER weather data before any operational use | All current numbers come from synthetic data | High (data is open) | Critical |
| R2 | Add location-specific features: soil type, irrigation access, and crop variety, at least per district | Finding 2: unexplained regional gap; LORO failure | Medium (requires data collection) | Critical |
| R3 | Adopt region-based validation as the standard acceptance test for any model before deployment | Finding 5: random validation overstates transferability | High | High |
| R4 | Add satellite vegetation indices (NDVI, EVI) at key growth stages | Captures crop condition directly; often more informative than weather alone | Medium (imagery access and processing) | High |
| R5 | Build scenario tools with automatic range checks, and label any out-of-range scenario as extrapolation | Finding 4: heat scenario was implausible | High (already implemented) | High |
| R6 | Extend the time series to at least 10 seasons per district | Needed to estimate heat and drought effects from real variation | Medium | High |
| R7 | Use simple, interpretable models as the default, and add complex models only when validated gains exceed a set threshold | Finding 3 | High | Medium |
| R8 | Build the disease classifier and price forecast, which were out of scope for this simulation | Two of the three original analytical goals are still open | Medium | Medium |
| R9 | Establish a seasonal monitoring cycle: retrain, compare forecasts with harvest outcomes, and review errors with agronomists | Keeps the model honest over time and detects drift | Medium | Medium |

## 7.1 Recommendations for operations

Beyond the technical steps, the analysis suggests practical uses for agribusiness operations once the model is validated on real data:

- **Harvest and logistics planning:** use an early season yield estimate, updated during the season, to schedule storage, transport, and buyer contracts. A mid-season update is more useful than a single pre-season forecast.
- **Input planning:** use rainfall and dry-day signals to decide on the timing of irrigation and fertiliser, prioritising areas where the model predicts stress.
- **Risk and finance:** use scenario outputs, with range checks, to support contingency budgets and conversations with insurers or lenders. Scenarios should be presented with their confidence level and the assumptions behind them.
- **Regional prioritisation:** compare actual and predicted yield by region. Persistent positive gaps indicate production advantages to learn from; persistent negative gaps indicate constraints that extension services or investment could address.

# 8. Real-World Implications and Limitations

## 8.1 Implications

If the approach holds on real data, a validated yield model would give agribusiness firms an earlier and more transparent view of supply. This could reduce stockouts and surplus losses, improve contract negotiation, and focus advisory resources on the areas that most need them. The greatest value is likely to come from using the model to ask better questions, such as why one region outperforms another, rather than from the point estimate itself.

There are also risks to manage. Farmers and buyers may rely on a model's output without understanding its limits. A model that performs well on average may fail in specific districts or in extreme seasons, which are often the seasons that matter most. Data collection can also reproduce existing inequalities if smallholders are under-represented in the statistics the model learns from. These risks argue for transparent communication, regional reporting of errors, and involvement of agronomists and local users from the start.

## 8.2 Limitations

- **Synthetic data.** The most important limitation. All numbers in this report are illustrative of the workflow, not of field performance.
- **Very small sample.** Twenty seasonal records cannot support confident conclusions about any model.
- **Weak temperature variation.** Heat effects cannot be estimated from the sample.
- **Limited features.** No soil, variety, management, or satellite information was used.
- **Two regions only.** Generalisation can be tested only at the level of these two sites.
- **Incomplete scope.** The disease and price models were not built.
- **Seasonal aggregation.** Weather was summarised over the whole season, which hides timing effects, such as stress during flowering.

# 9. Next Steps

**Immediate (next four weeks):**

1. Obtain and validate real BPS yield tables for the pilot district(s) and document units and revisions.
2. Download NASA POWER weather for the same locations and re-run `src/eda.py` and `src/train_yield_model.py` on the processed real data.
3. Confirm Sentinel-2 access and compute NDVI at three growth stages.
4. Re-evaluate all four models under LORO and update the decision on the selected model.

**Medium term (one to three months):**

5. Add soil and irrigation data to test whether they close the regional gap.
6. Build the disease classifier on PlantVillage and, separately, on field photographs to measure the domain gap.
7. Select a price data source and build a four-week forecast.
8. Run a pilot with one agribusiness partner in which the model's forecasts are compared with actual outcomes each season.

**Longer term (beyond the internship):**

9. Introduce a formal model governance process: documentation (model cards), version control, drift monitoring, and periodic review.
10. Integrate outputs into existing planning tools so that they inform decisions rather than sitting in a separate dashboard.

# 10. Learning Journey

This internship was my first experience of carrying an analytical project through all its stages, and the most important lesson was that the modelling is the smallest part of the work.

In Week 1 I learned that a clear problem statement and measurable targets are what make later decisions possible. Writing the KPIs before touching any data forced me to define what success would look like, and it later became clear that two of those targets could not be met within the project's timeframe. I would now set the scope more conservatively from the start.

In Week 2 I learned that data is rarely ready when you expect it. Several sources require accounts, manual downloads, or checks of licence terms, and the source for one of the three analytical goals had not been identified. Building the quality checks before the real data arrived was worthwhile, because it meant the method was tested and documented in advance.

In Week 3 I learned the most about evaluation. My first instinct was to choose the model with the best random cross-validation score, and that would have led to the wrong conclusion. Region-based validation showed that the model did not transfer. The heat scenario was the clearest lesson: a confident-looking number produced by a model can be meaningless when its inputs are outside the data. I now treat range checks and validation design as part of the model, not as an afterthought.

This week I learned that a report is an argument, not a summary. The hardest part was being honest about the gaps between the planned targets and the results. I chose to state those gaps plainly rather than present a more favourable picture, because the people who rely on this work need to know what is known and what is not.

Looking ahead, my priorities are to learn more about agronomy so that I can judge whether model features are plausible, to practise communicating uncertainty to non-technical audiences, and to build the habit of re-running analyses on real data as soon as it becomes available.

# 11. Conclusion

Over four weeks this project moved from a broad interest in agricultural analytics to a complete, reproducible analysis pipeline with documented planning, data understanding, modelling, and evaluation. On synthetic data, the selected ridge regression model achieved a typical error of about 8% when applied to an unseen region, but it did not meet the R² target and it did not transfer well between regions without location-specific information. Those are the central findings.

The most valuable outcome is not a model but a method: a way of testing claims about data that separates fit from transfer, separates a number from a decision, and states limitations openly. The next step is to run that method on real regional data, add the location-specific information the analysis identified as missing, and treat each season's results as a chance to learn.

# References

Breiman, L. (2001). Random forests. *Machine Learning, 45*(1), 5–32.

Chlingaryan, A., Sukkarieh, S., & Whelan, B. (2018). Machine learning approaches for crop yield prediction and nitrogen status estimation in precision agriculture: A review. *Computers and Electronics in Agriculture, 151*, 61–69.

Copernicus Programme, European Space Agency. *Sentinel-2 mission documentation*. https://sentinels.copernicus.org

Food and Agriculture Organization of the United Nations (FAO). (2017). *The future of food and agriculture: Trends and challenges*. Rome: FAO.

Friedman, J. H. (2001). Greedy function approximation: A gradient boosting machine. *The Annals of Statistics, 29*(5), 1189–1232.

Hoerl, A. E., & Kennard, R. W. (1970). Ridge regression: Biased estimation for nonorthogonal problems. *Technometrics, 12*(1), 55–67.

Hughes, D. P., & Salathé, M. (2015). An open access repository of images on plant health to enable the development of mobile disease diagnostics. *arXiv preprint arXiv:1511.08060*.

Liakos, K. G., Busato, P., Moshou, D., Pearson, S., & Bochtis, D. (2018). Machine learning in agriculture: A review. *Sensors, 18*(8), 2674.

Mitchell, M., et al. (2019). Model cards for model reporting. *Proceedings of the Conference on Fairness, Accountability, and Transparency (FAT\*)*, 220–229.

NASA Prediction Of Worldwide Energy Resources (POWER) Project. https://power.larc.nasa.gov

Pedregosa, F., Varoquaux, G., Gramfort, A., et al. (2011). Scikit-learn: Machine learning in Python. *Journal of Machine Learning Research, 12*, 2825–2830.

Shearer, C. (2000). The CRISP-DM model: The new blueprint for data mining. *Journal of Data Warehousing, 5*(4), 13–22.
