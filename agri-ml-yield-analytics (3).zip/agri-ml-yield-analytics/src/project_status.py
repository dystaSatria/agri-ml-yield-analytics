"""Week 4: verify that every project deliverable exists and write a status summary.

Run with:  python -m src.project_status
"""
import pandas as pd

from src.config import PROJECT_ROOT, REPORTS_DIR
from src.eda import to_md_table

DELIVERABLES = {
    "Week 1 strategic plan (Word)": "docs/Week1_Strategic_Plan.docx",
    "Week 2 data understanding (Word)": "docs/Week2_Data_Understanding.docx",
    "Week 3 execution and modelling (Word)": "docs/Week3_Execution_and_Modeling.docx",
    "Week 4 final project report (Word)": "docs/Week4_Final_Project_Report.docx",
    "Dataset catalogue": "data/catalogue.csv",
    "Week 2 data quality report": "reports/week2_data_quality.md",
    "Week 3 model results": "reports/week3_model_results.md",
}


def check_deliverables(root=PROJECT_ROOT) -> pd.DataFrame:
    """Return one row per deliverable with a boolean 'present' flag."""
    return pd.DataFrame([
        {"deliverable": name, "path": path, "present": (root / path).exists()}
        for name, path in DELIVERABLES.items()
    ])


def main() -> str:
    status = check_deliverables()
    complete = int(status["present"].sum())
    lines = ["# Project Status", "",
             f"Deliverables present: {complete} of {len(status)}.", "",
             to_md_table(status), ""]
    report = "\n".join(lines)
    REPORTS_DIR.mkdir(parents=True, exist_ok=True)
    (REPORTS_DIR / "project_status.md").write_text(report, encoding="utf-8")
    print(report)
    return report


if __name__ == "__main__":
    main()
